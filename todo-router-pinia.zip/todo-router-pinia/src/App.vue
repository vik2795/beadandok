<script setup>
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
  <div id="app">
    <nav>
      <router-link to="/">Kezdőlap</router-link> <br>
      <router-link :to="{ name: 'editnewtask', query: { id: 1 } }">Feladat módosítása</router-link>  <!--editnewtask nevű útvonalra visz,az id = 1 paraméterrel az URL-ben továbbítja.-->
    </nav>
    <router-view />
  </div>
</template>

