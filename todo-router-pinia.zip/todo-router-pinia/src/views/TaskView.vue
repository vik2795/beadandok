<script setup>
  import { useTaskStore } from '@/stores/task';
  const tasks = useTaskStore();
</script>

<template>
  <h1>Feladatok listája</h1>
  <div v-for="t in tasks.tasks" :key="t.id" class="task">
    <h3>{{ t.title }}</h3>
    <p>{{ t.desc }}</p>
    <div v-if="!t.isFinished">
      <button @click="toggleTask(t)">Kész</button>
    </div>
    <div v-if="t.isFinished">
      <button @click="toggleTask(t)">Nincs kész</button>
      <button @click="$router.push({ name: 'editnewtask', query: { id: t.id } })">Szerkesztés</button>
    </div>
  </div>
</template>

<style scoped>
.task {
  padding: 5px;
  width: 25%;
  border: 1px solid;
  border-radius: 5px;
}
.task button {
  display: block;
  margin: 0 auto;
}
</style>
