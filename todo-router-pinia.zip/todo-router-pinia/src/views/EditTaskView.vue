<template>
    <h1>Feladat módosítása</h1> 
    <form @submit.prevent="updateTask">
      <input type="text" v-model="title" placeholder="Feladat neve">
      <textarea v-model="desc"></textarea>
      <button>Mentés</button>
    </form>
  </template> <!--Létrehoztam egy formot amiben módosítani lehet az adott feladat nevét és leírását is-->
  
  <script setup> 
  import { useTaskStore } from '@/stores/task';
  import { ref } from 'vue';
  import { useRoute, useRouter } from 'vue-router'; 
  
  
  const tasks = useTaskStore();
  const route = useRoute();
  const router = useRouter();
  

  const taskId = parseInt(route.query.id, 10); 
  const task = tasks.tasks.find((t) => t.id === taskId);
  

  const title = ref(task ? task.title : ''); //fríssíti a feladat címét
  const desc = ref(task ? task.desc : '');  //frissíti a feladat leírását.
  
  const updateTask = () => {
    if (task) {
      task.title = title.value;
      task.desc = desc.value;
      router.push('/'); //Ezzel küldöm vissza a felhasználót az oldalra
    }
  };
  </script>
  <!--Itt formáztam meg a formot-->
  <style scoped>
  form {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 400px;
    margin: 0 auto;
  }
  input, textarea, button {
    padding: 8px;
    font-size: 1rem;
  }
  </style>
  