<template>
   
  <nav>
   
    <div>

      <RouterLink to="/posts">Posts</RouterLink>

    </div>



  </nav>
  
 <RouterView/>
  </template>
 