<template>
  <div class="posts">
    <h1>Posts</h1>
    <ul>
      <li>
        <RouterLink to="/postsDetail/id1">Post 1</RouterLink>
      </li>

      <li>
        <RouterLink to="/postsDetail/id2">Post 2</RouterLink>
      </li>

      <li>
        <RouterLink to="/postsDetail/id3">Post 3</RouterLink>
      </li> 


    </ul>

   
  </div>
</template>
<script setup></script>
<style scoped>
ul{
  margin-bottom: 30px;
}
</style>
