<template>
  <div class="post-detail">
    <h1>Post Details</h1>
    <p>Display the content of post with ID of {{$route.params.id}} here!</p>
    
    <div>
      <button @click="showPostID">Show post ID</button>
    </div>
    <div>
      <button @click="gohome">Go Home in 3 sec</button>
    </div>
    <p><RouterLink to="/posts">&lt; Back</RouterLink></p>
    
  </div>
</template>


<script setup>
import { useRoute ,useRouter} from 'vue-router';

const route=useRoute()
const router=useRouter()

const showPostID=()=>
{
  alert(`The ID od this post is : ${route.params.id}`)
}
const gohome=()=>
{
  setTimeout(()=>{router.push('/')},3000)
}

</script>
