<template>
    <h1>Feladat módosítása</h1> 
    <form @submit.prevent="updateTask">
      <input type="text" v-model="title" placeholder="Feladat neve">
      <textarea v-model="desc"></textarea>
      <button>Mentés</button>
    </form>
  </template>
  
  <script setup> 
  import { useTaskStore } from '@/stores/task';
  import { ref } from 'vue';
  import { useRoute, useRouter } from 'vue-router'; 
  
  
  const tasks = useTaskStore();
  const route = useRoute();
  const router = useRouter();
  

  const taskId = parseInt(route.query.id, 10); 
  const task = tasks.tasks.find((t) => t.id === taskId);
  

  const title = ref(task ? task.title : ''); 
  const desc = ref(task ? task.desc : ''); 
  
  const updateTask = () => {
    if (task) {
      task.title = title.value;
      task.desc = desc.value;
      router.push('/');
    }
  };
  </script>
  <style scoped>
  form {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 397px;
    margin: 0 auto;
  }
  input, textarea, button {
    padding: 7px;
    font-size: 1rem;
  }
  button{
    background-color: rgb(200, 173, 214);
    border-radius: 7%;
  }

  
  </style>
  