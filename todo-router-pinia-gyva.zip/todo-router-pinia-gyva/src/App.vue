<script setup>
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
  <div id="app">
    <nav>
      <router-link to="/">Kezdőlap</router-link> |
      <router-link to="/newtask">Új feladat</router-link> |
      <router-link :to="{ name: 'editnewtask', query: { id:1 } }">Feladat módosítása</router-link> |
      
    </nav>
    <router-view />
  </div>
</template>

