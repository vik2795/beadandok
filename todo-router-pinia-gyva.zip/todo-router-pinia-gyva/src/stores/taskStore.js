// src/stores/taskStore.js
import { defineStore } from 'pinia';

export const useTaskStore = defineStore('taskStore', {
    state: () => ({
        tasks: [
            { id: 1, title: 'Első feladat', description: 'Leírás', status: 'pending' },
            { id: 2, title: 'Második feladat', description: 'Leírás', status: 'completed' },
        ],
    }),
    getters: {
        pendingTasks(state) {
            return state.tasks.filter((task) => task.status === 'pending');
        },
    },
    actions: {
        updateTask(id, updatedData) {
            const taskIndex = this.tasks.findIndex((task) => task.id === id);
            if (taskIndex !== -1) {
                this.tasks[taskIndex] = { ...this.tasks[taskIndex], ...updatedData };
            }
        },
    },
});
