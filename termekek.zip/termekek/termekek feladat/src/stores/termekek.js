import { defineStore } from 'pinia';
import axios from 'axios';

export const useTermekekStore = defineStore('termekek', {
  state: () => ({
    termekek: []
  }),
  actions: {
    async fetchTermekek() {
      try {
        const response = await axios.get('http://localhost:3000/termekek');
        this.termekek = response.data;
      } catch (error) {
        console.error('Hiba történt:', error);
      }
    }
  }
});