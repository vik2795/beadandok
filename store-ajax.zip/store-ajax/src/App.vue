<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
import axios from 'axios'
import {onMounted} from 'vue'

onMounted(() => {
    axios.get('http://localhost:3000/todos')
    .then(resp => {
      console.table(resp.data)
    })
  })
</script>

<template>
  
</template>


